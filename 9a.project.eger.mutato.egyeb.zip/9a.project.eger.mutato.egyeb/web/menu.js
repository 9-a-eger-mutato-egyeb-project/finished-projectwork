var menu = false;


function menubar(){
    if(!menu){
        document.getElementById("md-smMenuRow").style.display = 'block';
        document.getElementById("exitDiv").style.display = 'block';
        setTimeout(function(){
            document.getElementById("md-smMenuRow").style.width = '360px';
            document.getElementById("rowA").style.width = '320px';
            document.getElementById("rowB").style.width = '320px';
            document.getElementById("rowC").style.width = '320px';
            document.getElementById("rowD").style.width = '320px';
        }, 1);
        menu = true;
    }else{
        document.getElementById("md-smMenuRow").style.width = '0px';
        document.getElementById("rowA").style.width = '0px';
        document.getElementById("rowB").style.width = '0px';
        document.getElementById("rowC").style.width = '0px';
        document.getElementById("rowD").style.width = '0px';
        setTimeout(function(){
            document.getElementById("md-smMenuRow").style.display = 'none';
            document.getElementById("exitDiv").style.display = 'none';
        }, 530);
        menu = false;
    }
}

function MenuExit(){
    document.getElementById("md-smMenuRow").style.width = '0px';
          document.getElementById("rowA").style.width = '0px';
          document.getElementById("rowB").style.width = '0px';
          document.getElementById("rowC").style.width = '0px';
          document.getElementById("rowD").style.width = '0px';
          setTimeout(function(){
              document.getElementById("md-smMenuRow").style.display = 'none';
          }, 530);
          menu = false;
  }

//KÉPEK
function openModal() {
    document.getElementById("myModal").style.display = "block";
  }
  
  function closeModal() {
    document.getElementById("myModal").style.display = "none";
  }
  
  var slideIndex = 1;
  showSlides(slideIndex);
  
  function plusSlides(n) {
    showSlides(slideIndex += n);
  }
  
  function currentSlide(n) {
    showSlides(slideIndex = n);
  }

  
  function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("demo");
    var captionText = document.getElementById("caption");
    if (n > slides.length) {slideIndex = 1}
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    captionText.innerHTML = dots[slideIndex-1].alt;
  }

//Tekerés tartalomhoz (direkt nem html-ben...)
  function lk(){
    document.getElementById('lk').scrollIntoView();
  }

  function lhf(){
    document.getElementById('lhf').scrollIntoView();
  }

  function dpi(){
    document.getElementById('dpi').scrollIntoView();
  }

  function pr(){
    document.getElementById('pr').scrollIntoView();
  }

  function ivge(){
    document.getElementById('ivge').scrollIntoView();
  }

//Szöveg másolása vágólapra
  function copyToClipboard(text) {
    var textarea = document.createElement('textarea');
   
    textarea.value = text;

    document.body.appendChild(textarea);
   
    textarea.select();
   
    document.execCommand('copy');
    
    document.body.removeChild(textarea);
    
    alert("e-mail cím vágólapra másolva!") //Visszajelzés
  }
  
//Ezt hívja meg a html:
  function masol(szoveg){
  copyToClipboard(szoveg);
  }